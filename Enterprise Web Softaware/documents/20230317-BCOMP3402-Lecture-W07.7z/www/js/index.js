function onAddToList() {
  let name  = $.trim($('#text-name').val())
  let email = $.trim($('#text-email').val())
  if (name==='' || email==='') {
    alert('Error: Both fields are required.')
    return
  }

  // DOM - Document Object Model
  /*
          <a href="#" class="list-group-item list-group-item-action" aria-current="true">
            <div class="d-flex w-100 justify-content-between">
              <h5 class="mb-1">John Smith</h5>
            </div>
            <p class="mb-1">john@outlook.com</p>
          </a>
  */

  let a   = $('<a></a>')
            .addClass('list-group-item list-group-item-action')
            .attr('href', '#')
            .attr('aria-current', 'true')
            .on('click', function(){
              let data = JSON.stringify({ 'name':name, 'email':email })
              window.open('user.html?params=' + encodeURIComponent(data), 'userWindow')
            })
  let div = $('<div></div>').addClass('d-flex w-100 justify-content-between')
  let h5  = $('<h5></h5>').addClass('mb-1').text(name)
  let p   = $('<p></p>').addClass('mb-1').text(email)

  $(div).append(h5)
  $(a).append(div).append(p)
  $('#list').append(a)
  $('#list').parent().removeClass('d-none')
}

document.addEventListener('deviceready', function(){
  Zepto(function($){
    $('#button-add-to-list').on('click', onAddToList)
  })  
}, false)
